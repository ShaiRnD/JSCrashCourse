# leads exercise

1. write a program to aggragate the files supplied.

the result will be an array like so:

```
[{
    "facebookID":"100002624888449",
    "fullName":"Chip Munk",
    "email":"ChipMunkilein@facebook.com"
},
{
  ...
}]
```

the purpose is to eliminate duplicate data found in the different files

2. write the result array to `results.json`



